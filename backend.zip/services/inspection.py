"""
Service de gestion des sessions d'inspection.
Orchestre : ouverture caméra → pipeline IA → sauvegarde résultats →
            déclenchement alertes → broadcast WebSocket.
"""

import asyncio
import logging
from datetime import datetime, timezone
from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from models.orm import (
    InspectionSession, InspectionResult, Lot, LotStatusEnum,
    DecisionEnum, DefectTypeEnum, Alert, AlertLevelEnum, AlertStatusEnum
)
from services.camera import CameraStream
from services.inference import inspecter_frame, _load_models, get_pipeline_status
from config import settings

logger = logging.getLogger(__name__)

# Sessions actives en mémoire : session_id → CameraStream
_active_streams: dict[int, CameraStream] = {}
# Résultats live en mémoire pour le polling : session_id → last_result
_live_results: dict[int, dict] = {}
# Compteurs consécutifs non-conformes pour alertes
_consecutive_nc: dict[int, int] = {}
# Compteur de frames pour commit groupé (1 commit toutes les N frames)
_frame_counters: dict[int, int] = {}
COMMIT_EVERY_N_FRAMES = 5


async def cleanup_stale_sessions(db: AsyncSession):
    """Marque toutes les sessions EN_COURS comme arrêtées au démarrage."""
    try:
        result = await db.execute(
            select(InspectionSession).where(InspectionSession.is_active == True)
        )
        stale = result.scalars().all()
        for s in stale:
            s.is_active = False
            s.stopped_at = datetime.now(timezone.utc)
            logger.info(f"Session orpheline {s.id} marquée comme arrêtée")
        if stale:
            await db.commit()
            logger.info(f"{len(stale)} session(s) orpheline(s) nettoyée(s)")
    except Exception as e:
        logger.error(f"Erreur cleanup sessions: {e}")


async def demarrer_session(
    db: AsyncSession,
    lot_id: int,
    camera_index: int,
    conformity_threshold: float,
    notes: Optional[str] = None
) -> InspectionSession:
    """Crée la session en DB et ouvre la caméra."""

    # Vérifier que le lot existe
    lot = await db.get(Lot, lot_id)
    if not lot:
        raise ValueError(f"Lot {lot_id} introuvable")

    # Mettre le lot en cours
    lot.status = LotStatusEnum.EN_COURS
    await db.flush()

    # Créer la session
    session = InspectionSession(
        lot_id=lot_id,
        camera_index=camera_index,
        conformity_threshold=conformity_threshold,
        notes=notes,
        is_active=True
    )
    db.add(session)
    await db.commit()
    await db.refresh(session)

    # Ouvrir la caméra
    stream = CameraStream(camera_index)
    if not stream.open():
        session.is_active = False
        await db.commit()
        raise RuntimeError(f"Impossible d'ouvrir la caméra {camera_index}")

    _active_streams[session.id] = stream
    _live_results[session.id] = {}
    _consecutive_nc[session.id] = 0
    _frame_counters[session.id] = 0

    logger.info(f"Session {session.id} démarrée — Lot {lot_id} — Caméra {camera_index}")
    return session


async def arreter_session(db: AsyncSession, session_id: int) -> InspectionSession:
    """Arrête la session, libère la caméra, calcule les stats finales."""

    session = await db.get(InspectionSession, session_id)
    if not session:
        raise ValueError(f"Session {session_id} introuvable")

    # Fermer la caméra
    if session_id in _active_streams:
        _active_streams[session_id].close()
        del _active_streams[session_id]

    # Nettoyer la mémoire
    _live_results.pop(session_id, None)
    _consecutive_nc.pop(session_id, None)
    _frame_counters.pop(session_id, None)

    # Calculer le taux de conformité final
    total = session.total_inspected
    if total > 0:
        session.conformity_rate = round(session.total_conforme / total * 100, 2)

    session.is_active = False
    session.stopped_at = datetime.now(timezone.utc)

    try:
        await db.commit()
        await db.refresh(session)
    except Exception as e:
        logger.error(f"Erreur commit arrêt session {session_id}: {e}")
        await db.rollback()

    logger.info(
        f"Session {session_id} arrêtée — "
        f"{total} inspectés — "
        f"Conformité : {session.conformity_rate:.1f}%"
    )
    return session


async def traiter_frame_inspection(db: AsyncSession, session_id: int) -> dict:
    """
    Capture une frame, lance le pipeline IA, sauvegarde le résultat.
    Appelé en boucle par le WebSocket ou en polling.
    Commit groupé toutes les COMMIT_EVERY_N_FRAMES frames pour éviter database is locked.
    """

    session = await db.get(InspectionSession, session_id)
    if not session or not session.is_active:
        return {"error": "Session inactive"}

    stream = _active_streams.get(session_id)
    if not stream:
        return {"error": "Caméra non disponible"}

    # Lire le frame
    frame = stream.read_frame()
    if frame is None:
        return {"error": "Impossible de lire le frame"}

    # Pipeline IA
    result = inspecter_frame(frame)

    if result.get("decision") == "NO_OBJECT":
        live = {**result, "session_id": session_id,
                "total_inspected": session.total_inspected,
                "conformity_rate": session.conformity_rate}
        _live_results[session_id] = live
        return live

    # Sauvegarder le résultat
    decision_enum = DecisionEnum(result["decision"])
    inspection_result = InspectionResult(
        session_id=session_id,
        decision=decision_enum,
        anomaly_score=result.get("anomaly_score"),
        yolo_confidence=result.get("yolo_confidence"),
        analysis_duration_ms=result.get("analysis_duration_ms"),
        bbox_x1=result["bbox"][0] if result.get("bbox") else None,
        bbox_y1=result["bbox"][1] if result.get("bbox") else None,
        bbox_x2=result["bbox"][2] if result.get("bbox") else None,
        bbox_y2=result["bbox"][3] if result.get("bbox") else None,
    )
    db.add(inspection_result)

    # Mettre à jour les compteurs de la session
    session.total_inspected += 1
    if decision_enum == DecisionEnum.CONFORME:
        session.total_conforme += 1
        _consecutive_nc[session_id] = 0
    elif decision_enum == DecisionEnum.SUSPECT:
        session.total_suspect += 1
    elif decision_enum == DecisionEnum.NON_CONFORME:
        session.total_non_conforme += 1
        _consecutive_nc[session_id] = _consecutive_nc.get(session_id, 0) + 1

    # Taux de conformité live
    if session.total_inspected > 0:
        session.conformity_rate = round(
            session.total_conforme / session.total_inspected * 100, 2
        )

    # Commit groupé : toutes les N frames seulement
    _frame_counters[session_id] = _frame_counters.get(session_id, 0) + 1
    if _frame_counters[session_id] >= COMMIT_EVERY_N_FRAMES:
        _frame_counters[session_id] = 0
        try:
            await db.commit()
        except Exception as e:
            logger.warning(f"Commit frame ignoré (db busy): {e}")
            await db.rollback()

    # Vérifier si une alerte doit être déclenchée
    try:
        await _verifier_alertes(db, session, result)
    except Exception as e:
        logger.warning(f"Alerte ignorée (db busy): {e}")

    # Stocker pour polling
    live = {
        **result,
        "session_id": session_id,
        "result_id": getattr(inspection_result, 'id', None),
        "total_inspected": session.total_inspected,
        "total_conforme": session.total_conforme,
        "total_suspect": session.total_suspect,
        "total_non_conforme": session.total_non_conforme,
        "conformity_rate": session.conformity_rate,
        "timestamp": datetime.now(timezone.utc).isoformat()
    }
    _live_results[session_id] = live
    return live


def get_live_result(session_id: int) -> dict:
    """Retourne le dernier résultat disponible (pour polling HTTP)."""
    return _live_results.get(session_id, {})


def get_active_sessions() -> list[int]:
    return list(_active_streams.keys())


async def _verifier_alertes(db: AsyncSession, session: InspectionSession, result: dict):
    """Déclenche des alertes selon les règles configurées."""
    alerts_to_add = []

    # Règle 1 : Non-conformité critique isolée
    if result.get("decision") == "NON_CONFORME" and result.get("anomaly_score", 0) > 0.80:
        alerts_to_add.append(Alert(
            level=AlertLevelEnum.CRITIQUE,
            status=AlertStatusEnum.ACTIVE,
            message=f"Non-conformité critique détectée (score: {result['anomaly_score']:.3f})",
            session_id=session.id,
            lot_id=session.lot_id,
            trigger_value=result.get("anomaly_score")
        ))

    # Règle 2 : Non-conformités consécutives
    nc_count = _consecutive_nc.get(session.id, 0)
    if nc_count >= settings.ALERT_CONSECUTIVE_INSPECTIONS:
        alerts_to_add.append(Alert(
            level=AlertLevelEnum.CRITIQUE,
            status=AlertStatusEnum.ACTIVE,
            message=f"{nc_count} non-conformités consécutives détectées",
            session_id=session.id,
            lot_id=session.lot_id,
            trigger_value=float(nc_count)
        ))
        _consecutive_nc[session.id] = 0  # reset

    # Règle 3 : Taux de non-conformité global dépasse le seuil
    if session.total_inspected >= 10:
        nc_rate = session.total_non_conforme / session.total_inspected
        if nc_rate > settings.ALERT_NONCONFORMITY_RATE:
            alerts_to_add.append(Alert(
                level=AlertLevelEnum.AVERTISSEMENT,
                status=AlertStatusEnum.ACTIVE,
                message=f"Taux non-conformité élevé : {nc_rate*100:.1f}%",
                session_id=session.id,
                lot_id=session.lot_id,
                trigger_value=nc_rate
            ))

    for alert in alerts_to_add:
        db.add(alert)

    if alerts_to_add:
        try:
            await db.commit()
            logger.warning(f"⚠️  {len(alerts_to_add)} alerte(s) déclenchée(s) pour session {session.id}")
        except Exception as e:
            logger.warning(f"Commit alerte ignoré (db busy): {e}")
            await db.rollback()
